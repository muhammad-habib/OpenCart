<?php

$_['mastercard_pgs_extension_version'] = '2.0.4';
$_['mastercard_pgs_api_version'] = '40';
$_['mastercard_pgs_route'] = 'extension/payment/mastercard_pgs';
$_['mastercard_pgs_model_property'] = 'model_extension_payment_mastercard_pgs';
$_['mastercard_pgs_extension_route'] = 'extension/extension';
$_['mastercard_pgs_extension_type'] = '&type=payment';