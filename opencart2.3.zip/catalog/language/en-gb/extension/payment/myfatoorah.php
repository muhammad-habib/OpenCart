<?php
// Text
$_['text_title'] = 'Myfatoorah Checkout';
$_['button_confirm'] = 'Confirm Order';