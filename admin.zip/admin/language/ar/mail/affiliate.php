<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_approve_subject']      = '%s - تم تفعيل حسابك في برنامج نظام العمولة!';
$_['text_approve_welcome']      = 'شكراً لتسجيلك في %s!';
$_['text_approve_login']        = 'لقد تم إنشاء حسابك ويمكنك تسجيل الدخول من خلال الرابط التالي:';
$_['text_approve_services']     = 'بعد تسجيل الدخول يمكنك إنشاء شفرة التتبع, واختيار طريقة استلام الأموال وتحرير معلومات حسابك.';
$_['text_approve_thanks']       = 'شكراً لك,';
$_['text_transaction_subject']  = '%s - قيمة العمولة';
$_['text_transaction_received'] = 'لقد استلمت %s عمولة!';
$_['text_transaction_total']    = 'إجمالي قيمة عمولاتك %s.';