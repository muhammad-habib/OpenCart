<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_subject']       = '%s - تحديث إرجاع المنتج %s';
$_['text_return_id']     = 'رقم الإرجاع:';
$_['text_date_added']    = 'تاريخ الإرجاع:';
$_['text_return_status'] = 'تم تحديث إرجاع الطلب إلى:';
$_['text_comment']       = 'الملاحظات:';
$_['text_footer']        = 'الرجاء الرد على هذا البريد الالكتروني في حالة وجود استفسارات.';