<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'نسخة احتياطية / استعادة';

// Text
$_['text_success']     = 'تم تصدير قاعدة البيانات بنجاح !';

// Entry
$_['entry_import']     = 'استيراد';
$_['entry_export']     = 'تصدير';

// Error
$_['error_permission'] = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';
$_['error_export']     = 'تحذير : يجب اختيار جدول واحد على الأقل !';
$_['error_empty']      = 'تحذير : الملف الذي قمت باختياره فارغ !';