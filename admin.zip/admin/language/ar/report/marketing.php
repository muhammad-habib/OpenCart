<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'تقرير التسويق';

// Text
$_['text_list']         = 'قائمة';
$_['text_all_status']   = 'جميع الحالات';

// Column
$_['column_campaign']  = 'اسم الحملة';
$_['column_code']      = 'الرمز';
$_['column_clicks']    = 'النقرات';
$_['column_orders']    = 'رقم الطلب';
$_['column_total']     = 'الاجمالي';

// Entry
$_['entry_date_start'] = 'تاريخ البداية';
$_['entry_date_end']   = 'تاريخ النهاية';
$_['entry_status']     = 'حالة الطلب';